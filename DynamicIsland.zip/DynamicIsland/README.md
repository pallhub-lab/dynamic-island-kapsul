# Dynamic Island (Android)

Overlay kapsul ala Dynamic Island: pemutar musik, notifikasi semua aplikasi, dan indikator charger.

## Cara build
1. Buka folder ini di Android Studio (Koala / 2024.1 atau lebih baru). Biarkan Gradle sync selesai.
2. Build > Build APK(s), atau jalankan di HP.
   Lewat terminal: `./gradlew assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk

## PENTING: gunakan build RELEASE agar ringan
Build debug jauh lebih lambat untuk Compose. Pilih Build Variants > release, lalu Build > Build APK(s)
(atau `./gradlew assembleRelease` -> app/build/outputs/apk/release/app-release.apk).

## Cara pakai
Buka aplikasi, lalu berikan izin yang diminta berurutan:
notifikasi, tampil di atas aplikasi lain, dan akses notifikasi.
Kapsul muncul di tengah atas layar. Atur posisi & ukuran lewat slider di layar utama aplikasi, atau tekan lama kapsul lalu geser.

## Catatan
- Beberapa HP (Xiaomi/Oppo/Vivo) perlu autostart dan optimasi baterai dimatikan.
- Daftar aplikasi yang diblokir: `blockedApps` di MediaListenerService.kt.
