# Dynamic Island (Android)

Overlay kapsul ala Dynamic Island: pemutar musik, notifikasi semua aplikasi, dan indikator charger.

## Cara build
1. Buka folder ini di Android Studio (Koala / 2024.1 atau lebih baru). Biarkan Gradle sync selesai.
2. Build > Build APK(s), atau jalankan di HP.
   Lewat terminal: `./gradlew assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk

## Cara pakai
Buka aplikasi, lalu berikan izin yang diminta berurutan:
notifikasi, tampil di atas aplikasi lain, dan akses notifikasi.
Kapsul muncul di tengah atas layar. Sesuaikan `y` di OverlayService.showIsland() dengan posisi kamera HP.

## Catatan
- Beberapa HP (Xiaomi/Oppo/Vivo) perlu autostart dan optimasi baterai dimatikan.
- Daftar aplikasi yang diblokir: `blockedApps` di MediaListenerService.kt.
