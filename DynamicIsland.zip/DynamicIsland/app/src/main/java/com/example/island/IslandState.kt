package com.example.island

import kotlinx.coroutines.flow.MutableStateFlow

/** State bersama antara jendela pill (P) dan jendela besar (E). */
object IslandState {
    /** Panel musik dibuka (diketuk user). */
    val musicOpen = MutableStateFlow(false)

    /** Dinaikkan setiap user berinteraksi dengan panel musik (mengulang timer auto-tutup). */
    val tick = MutableStateFlow(0)

    /** true = jendela besar (E) sedang menggambar kapsul. */
    val bigActive = MutableStateFlow(false)

    /** true = jendela pill (P) berhenti menggambar karena E sedang menggambar. */
    val pillHidden = MutableStateFlow(false)

    fun toggleMusic() { musicOpen.value = !musicOpen.value }
    fun poke() { tick.value = tick.value + 1 }

    fun reset() {
        musicOpen.value = false
        bigActive.value = false
        pillHidden.value = false
    }
}
