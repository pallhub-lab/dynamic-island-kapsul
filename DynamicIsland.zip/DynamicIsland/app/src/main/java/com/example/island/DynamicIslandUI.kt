package com.example.island

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min

// ───────────── Konstanta tampilan ─────────────
private val IslandBlack = Color(0xFF000000)          // hitam pekat, menyatu dengan punch-hole
private val BoltGreen = Color(0xFF30D158)
private const val CORNER_EXPANDED_DP = 28f
private const val SPRING_DAMPING = 0.74f             // <1 = sedikit kenyal seperti iOS
private const val SPRING_STIFFNESS = 380f

// Batas ukuran mode notifikasi (compact)
private const val NOTIF_MAX_LINES = 2            // maks. baris pesan yang tampil
private const val NOTIF_MAX_H_DP = 84f           // tinggi maksimal mutlak panel notifikasi

/** Lebar panel notifikasi/musik: proporsional terhadap layar, tidak melebar berlebihan. */
fun islandWidthDp(screenW: Float): Float =
    (screenW * 0.78f).coerceIn(260f, 330f).coerceAtMost(screenW - 16f)

sealed interface IslandMode {
    val key: Int
    object Pill : IslandMode { override val key = 0 }
    object Music : IslandMode { override val key = 1 }
    data class Notif(val info: NotifInfo) : IslandMode { override val key = 2 }
    data class Charge(val info: ChargeInfo) : IslandMode { override val key = 3 }
}

// ───────────── Dua jendela ─────────────
//  P  = jendela pill: ukuran & posisi TETAP (seukuran pill). Menggambar kapsul saat idle.
//  E  = jendela besar: ukuran & posisi TETAP. Menggambar kapsul saat membesar (notifikasi, musik, charger).
// Karena frame kedua jendela tidak pernah berubah saat animasi, tidak ada lagi kapsul yang "bergeser".

@Composable
fun PillWindowUI() {
    val track by MediaRepo.track.collectAsState()
    val cfg by IslandPrefs.config.collectAsState()
    val hidden by IslandState.pillHidden.collectAsState()

    Box(
        Modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { IslandState.toggleMusic() }
    ) {
        if (!hidden) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(percent = 50))
                    .background(IslandBlack)
            ) { PillContent(track, cfg) }
        }
    }
}

@Composable
fun IslandWindowUI() {
    val active by IslandState.bigActive.collectAsState()
    val d = LocalDensity.current
    // Abaikan pembesaran font sistem agar proporsi kapsul selalu konsisten
    CompositionLocalProvider(LocalDensity provides Density(d.density, min(d.fontScale, 1f))) {
        if (active) IslandSurface()
    }
}

@Composable
private fun IslandSurface() {
    val track by MediaRepo.track.collectAsState()
    val notif by MediaRepo.notif.collectAsState()
    val charge by MediaRepo.charge.collectAsState()
    val musicOpen by IslandState.musicOpen.collectAsState()
    val cfg by IslandPrefs.config.collectAsState()
    val n = notif
    val c = charge

    // Mulai dari bentuk pill (identik dengan jendela P), baru berkembang setelah 2 frame
    var ready by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        withFrameNanos { }
        withFrameNanos { }
        ready = true
    }

    val target: IslandMode = when {
        n != null -> IslandMode.Notif(n)
        c != null -> IslandMode.Charge(c)
        musicOpen -> IslandMode.Music
        else -> IslandMode.Pill
    }
    val mode: IslandMode = if (ready) target else IslandMode.Pill

    val h = cfg.pillHeightDp
    val screenW = LocalConfiguration.current.screenWidthDp.toFloat()
    // Notifikasi: selebar layar (menutup ikon status bar) atau 78% layar; musik selalu 78%
    val notifW = if (cfg.coverStatusBar) screenW - 16f else islandWidthDp(screenW)
    val musicW = islandWidthDp(screenW)
    val activeW = when (mode) {
        is IslandMode.Notif -> notifW
        IslandMode.Music -> musicW
        else -> 0f
    }

    // Sudut: pill/charger = lonjong sempurna, panel besar = membulat
    val corner by animateDpAsState(
        targetValue = if (mode == IslandMode.Pill || mode is IslandMode.Charge) (h / 2f).dp
        else CORNER_EXPANDED_DP.dp,
        animationSpec = spring(dampingRatio = SPRING_DAMPING, stiffness = SPRING_STIFFNESS),
        label = "corner"
    )

    // Jendela besar (E) selalu di x = 0 selebar layar, jadi posisi horizontal diatur di sini.
    //  - Pill / charger : tepat di posisi kamera (xDp; 0 jika kamera di tengah -> terkunci di tengah)
    //  - Notifikasi lebar-penuh : di tengah layar
    //  - Lainnya : di posisi kamera, digeser masuk hanya jika akan keluar layar
    val pillCenter = screenW / 2f + cfg.xDp
    val targetCenter = when {
        mode == IslandMode.Pill || mode is IslandMode.Charge -> pillCenter
        cfg.coverStatusBar && mode is IslandMode.Notif -> screenW / 2f
        else -> {
            val minC = 8f + activeW / 2f
            val maxC = screenW - 8f - activeW / 2f
            if (minC > maxC) screenW / 2f else pillCenter.coerceIn(minC, maxC)
        }
    }
    val shift by animateDpAsState(
        targetValue = (targetCenter - screenW / 2f).dp,
        animationSpec = spring(dampingRatio = SPRING_DAMPING, stiffness = SPRING_STIFFNESS),
        label = "shift"
    )

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Box(
            Modifier
                .offset(x = shift)
                .clip(RoundedCornerShape(corner))
                .background(IslandBlack)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    if (n != null) {
                        try { n.intent?.send() } catch (_: Exception) {}
                        MediaRepo.dismissNotifs()
                    } else if (c != null) {
                        MediaRepo.charge.value = null
                    } else {
                        IslandState.toggleMusic()
                    }
                }
        ) {
            AnimatedContent(
                targetState = mode,
                // Tumbuh dari tengah-atas -> melebar ke samping & ke BAWAH, seperti Dynamic Island iPhone
                contentAlignment = Alignment.TopCenter,
                transitionSpec = {
                    val enter = fadeIn(tween(180, delayMillis = 60)) +
                        scaleIn(
                            initialScale = 0.85f,
                            transformOrigin = TransformOrigin(0.5f, 0f),
                            animationSpec = spring(dampingRatio = SPRING_DAMPING, stiffness = SPRING_STIFFNESS)
                        )
                    val exit = fadeOut(tween(90))
                    (enter togetherWith exit).using(
                        SizeTransform(clip = false) { _, _ ->
                            spring<IntSize>(dampingRatio = SPRING_DAMPING, stiffness = SPRING_STIFFNESS)
                        }
                    )
                },
                contentKey = { it.key },
                label = "island"
            ) { m ->
                when (m) {
                    IslandMode.Pill -> PillContent(track, cfg)
                    IslandMode.Music -> MusicContent(track, musicW, h)
                    is IslandMode.Notif -> NotifContent(n ?: m.info, notifW, cfg)
                    is IslandMode.Charge -> ChargeContent(c?.level ?: m.info.level, cfg)
                }
            }
        }
    }
}

// ───────────── Pill (idle) ─────────────

@Composable
private fun PillContent(track: TrackInfo?, cfg: IslandConfig) {
    val h = cfg.pillHeightDp
    val artSize = (h * 0.6f).dp
    // Sisi kiri/kanan dipakai, bagian tengah dibiarkan kosong untuk kamera
    Row(
        Modifier
            .size(cfg.pillWidthDp.dp, h.dp)
            .padding(horizontal = (h * 0.2f).dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val art = track?.art
        if (art != null) {
            BitmapImage(art, artSize, RoundedCornerShape((artSize.value * 0.28f).dp))
        } else {
            Spacer(Modifier.size(artSize))
        }
        if (track?.isPlaying == true) {
            Waveform(Color.White, scale = h / 40f)   // statis (tanpa animasi) agar hemat baterai
        } else {
            Spacer(Modifier.size(artSize))
        }
    }
}

// ───────────── Charger: pill sedikit lebih lebar, kiri ⚡ kanan persen ─────────────

@Composable
private fun ChargeContent(level: Int, cfg: IslandConfig) {
    val h = cfg.pillHeightDp
    Row(
        Modifier
            .size((cfg.pillWidthDp + 90f).dp, h.dp)
            .padding(horizontal = (h * 0.38f).dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BoltIcon((h * 0.5f).dp)
        Text("$level%", color = BoltGreen, fontWeight = FontWeight.Bold, fontSize = (h * 0.42f).sp)
    }
}

@Composable
private fun BoltIcon(size: Dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val hh = this.size.height
        val p = Path().apply {
            moveTo(w * 0.60f, 0f)
            lineTo(w * 0.15f, hh * 0.58f)
            lineTo(w * 0.47f, hh * 0.58f)
            lineTo(w * 0.38f, hh)
            lineTo(w * 0.85f, hh * 0.38f)
            lineTo(w * 0.52f, hh * 0.38f)
            close()
        }
        drawPath(p, BoltGreen)
    }
}

// ───────────── Notifikasi (compact) ─────────────

/**
 * Susunan dua bagian:
 *  1) "Band kamera": tinggi = tinggi pill, sejajar punch-hole. Kiri = foto + nama pengirim,
 *     kanan = nama aplikasi; bagian tengah dikosongkan untuk kamera. Tidak ada padding atas ekstra,
 *     jadi kapsul menyatu dengan area kamera.
 *  2) Pesan (maks. NOTIF_MAX_LINES baris) tepat di bawah band.
 * Tinggi total dibatasi NOTIF_MAX_H_DP.
 */
@Composable
private fun NotifContent(n: NotifInfo, widthDp: Float, cfg: IslandConfig) {
    val pillH = cfg.pillHeightDp
    val lines = n.lines.ifEmpty { listOf(n.text).filter { it.isNotEmpty() } }
    val shown = lines.takeLast(NOTIF_MAX_LINES)
    // Lebar sisi kiri/kanan band = (lebar panel - lebar area kamera) / 2 - padding
    val sideW = ((widthDp - cfg.pillWidthDp) / 2f - 14f).coerceAtLeast(60f)
    val trailing = if (lines.size > 1) "${n.appName} · ${lines.size}" else n.appName

    Column(
        Modifier
            .width(widthDp.dp)
            .heightIn(max = NOTIF_MAX_H_DP.dp)
            .animateContentSize(spring<IntSize>(dampingRatio = SPRING_DAMPING, stiffness = SPRING_STIFFNESS))
            .padding(bottom = if (shown.isEmpty()) 0.dp else 10.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(pillH.dp)
                .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(Modifier.width(sideW.dp), verticalAlignment = Alignment.CenterVertically) {
                val icon = n.icon
                if (icon != null) {
                    BitmapImage(icon, 22.dp, CircleShape)
                } else {
                    Box(Modifier.size(22.dp).clip(CircleShape).background(Color(0xFF2C2C2E)))
                }
                Spacer(Modifier.width(6.dp))
                Text(
                    n.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                trailing, color = Color(0xFF8E8E93), fontSize = 10.sp, textAlign = TextAlign.End,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.width(sideW.dp)
            )
        }
        if (shown.isNotEmpty()) {
            Column(Modifier.padding(horizontal = 16.dp)) {
                shown.forEach { line ->
                    Text(
                        line, color = Color(0xFFD1D1D6), fontSize = 12.sp,
                        maxLines = if (shown.size == 1) 2 else 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

// ───────────── Musik ─────────────

@Composable
private fun MusicContent(track: TrackInfo?, widthDp: Float, pillH: Float) {
    // Padding atas = tinggi pill: isi mulai tepat di bawah area kamera
    Column(
        Modifier
            .width(widthDp.dp)
            .padding(start = 16.dp, end = 16.dp, top = pillH.dp, bottom = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val art = track?.art
            if (art != null) {
                BitmapImage(art, 44.dp, RoundedCornerShape(10.dp))
            } else {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2C2C2E)))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    track?.title ?: "Tidak ada musik",
                    color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    track?.artist.orEmpty(),
                    color = Color(0xFF9A9AA0), fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (track?.isPlaying == true) Waveform(Color.White, scale = 0.85f)
        }
        Spacer(Modifier.height(6.dp))
        if (track != null) ProgressBar(track) else Spacer(Modifier.height(4.dp))
        Spacer(Modifier.height(2.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBtn({ MediaRepo.controller?.transportControls?.skipToPrevious(); IslandState.poke() }) {
                SkipIcon(next = false)
            }
            IconBtn({
                val tc = MediaRepo.controller?.transportControls
                if (track?.isPlaying == true) tc?.pause() else tc?.play()
                IslandState.poke()
            }) { PlayPauseIcon(track?.isPlaying == true) }
            IconBtn({ MediaRepo.controller?.transportControls?.skipToNext(); IslandState.poke() }) {
                SkipIcon(next = true)
            }
        }
    }
}

/**
 * Progress bar tanpa polling: satu animasi linear dari posisi sekarang sampai akhir lagu,
 * dimulai ulang hanya saat lagu/status play berubah, dan dibaca di fase draw saja.
 */
@Composable
private fun ProgressBar(track: TrackInfo) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(
        track.title, track.isPlaying, track.basePositionMs, track.baseTimeMs, track.durationMs
    ) {
        if (track.durationMs <= 0L) {
            progress.snapTo(0f)
            return@LaunchedEffect
        }
        val speed = track.speed.coerceAtLeast(0.1f)
        val now = if (track.isPlaying) {
            track.basePositionMs + ((SystemClock.elapsedRealtime() - track.baseTimeMs) * speed).toLong()
        } else track.basePositionMs
        val pos = now.coerceIn(0L, track.durationMs)
        progress.snapTo(pos.toFloat() / track.durationMs)
        if (track.isPlaying) {
            val remaining = ((track.durationMs - pos) / speed).toInt().coerceAtLeast(1)
            progress.animateTo(1f, tween(remaining, easing = LinearEasing))
        }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(Color(0x33FFFFFF))
            .drawBehind {
                drawRect(Color(0xCCFFFFFF), size = Size(size.width * progress.value, size.height))
            }
    )
}

// ───────────── Komponen kecil ─────────────

@Composable
private fun BitmapImage(bitmap: Bitmap, size: Dp, shape: Shape) {
    val img = remember(bitmap) { bitmap.asImageBitmap() }
    Image(
        bitmap = img,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(shape)
    )
}

@Composable
private fun IconBtn(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) { content() }
}

/** Ikon waveform statis (5 batang), tanpa animasi. */
@Composable
private fun Waveform(color: Color, scale: Float) {
    val heights = floatArrayOf(8f, 14f, 20f, 12f, 6f)
    Row(
        horizontalArrangement = Arrangement.spacedBy((2f * scale).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        heights.forEach {
            Box(
                Modifier
                    .width((3f * scale).dp)
                    .height((it * scale).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
        }
    }
}

@Composable
private fun PlayPauseIcon(playing: Boolean) {
    Canvas(Modifier.size(26.dp)) {
        val w = size.width
        val h = size.height
        if (playing) {
            val bw = w * 0.22f
            drawRoundRect(Color.White, Offset(w * 0.18f, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(bw * 0.3f))
            drawRoundRect(Color.White, Offset(w * 0.60f, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(bw * 0.3f))
        } else {
            val p = Path().apply {
                moveTo(w * 0.22f, h * 0.10f)
                lineTo(w * 0.86f, h * 0.50f)
                lineTo(w * 0.22f, h * 0.90f)
                close()
            }
            drawPath(p, Color.White)
        }
    }
}

@Composable
private fun SkipIcon(next: Boolean) {
    Canvas(Modifier.size(26.dp)) {
        val w = size.width
        val h = size.height
        val p = Path()
        fun tri(x0: Float, x1: Float) {
            if (next) {
                p.moveTo(x0, h * 0.2f); p.lineTo(x1, h * 0.5f); p.lineTo(x0, h * 0.8f)
            } else {
                p.moveTo(x1, h * 0.2f); p.lineTo(x0, h * 0.5f); p.lineTo(x1, h * 0.8f)
            }
            p.close()
        }
        tri(w * 0.05f, w * 0.50f)
        tri(w * 0.50f, w * 0.95f)
        drawPath(p, Color.White)
    }
}
