package com.example.island

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.min

// ───────────── Konstanta tampilan ─────────────
private val IslandBlack = Color(0xFF000000)          // hitam pekat, menyatu dengan punch-hole
private const val EXPANDED_CORNER_DP = 38f
private const val SPRING_DAMPING = 0.74f             // <1 = sedikit kenyal (bouncy) seperti iOS
private const val SPRING_STIFFNESS = 380f

/** Mode tampilan kapsul. `key` dipakai agar perubahan data di mode yang sama tidak memicu animasi ulang. */
sealed interface IslandMode {
    val key: Int
    object Pill : IslandMode { override val key = 0 }
    object Music : IslandMode { override val key = 1 }
    data class Notif(val info: NotifInfo) : IslandMode { override val key = 2 }
    data class Charge(val info: ChargeInfo) : IslandMode { override val key = 3 }
}

/** Tinggi window (dp) yang dibutuhkan tiap mode. 0 = ukuran pill (window kecil). */
private fun windowHeightFor(m: IslandMode): Float = when (m) {
    IslandMode.Pill -> 0f
    IslandMode.Music -> 176f
    is IslandMode.Notif -> 120f
    is IslandMode.Charge -> 112f
}

@Composable
fun IslandUI(onWindowHeight: (Float) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }   // reset timer auto-tutup saat user berinteraksi
    val track by MediaRepo.track.collectAsState()
    val notif by MediaRepo.notif.collectAsState()
    val charge by MediaRepo.charge.collectAsState()
    val cfg by IslandPrefs.config.collectAsState()
    val n = notif
    val c = charge

    // Semua "timer" di bawah hanya aktif saat ada event; tidak ada polling.
    LaunchedEffect(n) {
        if (n != null) {
            delay(5000)
            MediaRepo.notif.value = null
        }
    }
    LaunchedEffect(c) {
        if (c != null) {
            delay(4000)
            MediaRepo.charge.value = null
        }
    }
    LaunchedEffect(expanded, tick) {
        if (expanded) {
            delay(8000)
            expanded = false
        }
    }

    val mode: IslandMode = when {
        n != null -> IslandMode.Notif(n)
        c != null -> IslandMode.Charge(c)
        expanded -> IslandMode.Music
        else -> IslandMode.Pill
    }

    // Window membesar langsung, mengecil setelah animasi spring selesai
    LaunchedEffect(mode.key) {
        val h = windowHeightFor(mode)
        if (h > 0f) {
            onWindowHeight(h)
        } else {
            delay(650)
            onWindowHeight(0f)
        }
    }

    // Sudut: idle = lonjong sempurna (radius = setengah tinggi), expanded = membulat besar
    val corner by animateDpAsState(
        targetValue = if (mode == IslandMode.Pill) (cfg.pillHeightDp / 2f).dp else EXPANDED_CORNER_DP.dp,
        animationSpec = spring(dampingRatio = SPRING_DAMPING, stiffness = SPRING_STIFFNESS),
        label = "corner"
    )

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Box(
            Modifier
                .clip(RoundedCornerShape(corner))
                .background(IslandBlack)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    if (n != null) {
                        try { n.intent?.send() } catch (_: Exception) {}
                        MediaRepo.notif.value = null
                    } else if (c != null) {
                        MediaRepo.charge.value = null
                    } else {
                        expanded = !expanded
                    }
                }
        ) {
            AnimatedContent(
                targetState = mode,
                transitionSpec = {
                    val enter = fadeIn(tween(180, delayMillis = 60)) +
                        scaleIn(
                            initialScale = 0.85f,
                            transformOrigin = TransformOrigin(0.5f, 0f),
                            animationSpec = spring(dampingRatio = SPRING_DAMPING, stiffness = SPRING_STIFFNESS)
                        )
                    val exit = fadeOut(tween(90))
                    (enter togetherWith exit).using(
                        SizeTransform(clip = false) { _, _ ->
                            spring<IntSize>(dampingRatio = SPRING_DAMPING, stiffness = SPRING_STIFFNESS)
                        }
                    )
                },
                contentKey = { it.key },
                label = "island"
            ) { m ->
                when (m) {
                    IslandMode.Pill -> PillContent(track, cfg)
                    IslandMode.Music -> MusicContent(track) { tick++ }
                    is IslandMode.Notif -> NotifContent(m.info)
                    is IslandMode.Charge -> ChargeContent(m.info.level)
                }
            }
        }
    }
}

// ───────────── Pill (idle) ─────────────

@Composable
private fun PillContent(track: TrackInfo?, cfg: IslandConfig) {
    val h = cfg.pillHeightDp
    val artSize = (h * 0.6f).dp
    // Ukuran = ukuran punch-hole + padding. Sisi kiri/kanan dipakai, tengah dibiarkan kosong untuk kamera.
    Row(
        Modifier
            .size(cfg.pillWidthDp.dp, h.dp)
            .padding(horizontal = (h * 0.2f).dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val art = track?.art
        if (art != null) {
            BitmapImage(art, artSize, RoundedCornerShape((artSize.value * 0.28f).dp))
        } else {
            Spacer(Modifier.size(artSize))
        }
        if (track?.isPlaying == true) {
            Waveform(Color.White, scale = h / 40f)   // statis (tanpa animasi) agar hemat baterai
        } else {
            Spacer(Modifier.size(artSize))
        }
    }
}

// ───────────── Musik ─────────────

@Composable
private fun MusicContent(track: TrackInfo?, onInteract: () -> Unit) {
    val screenW = LocalConfiguration.current.screenWidthDp
    val w = min(344, screenW - 40).dp
    Column(Modifier.width(w).padding(horizontal = 18.dp, vertical = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val art = track?.art
            if (art != null) {
                BitmapImage(art, 56.dp, RoundedCornerShape(14.dp))
            } else {
                Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF2C2C2E)))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    track?.title ?: "Tidak ada musik",
                    color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    track?.artist.orEmpty(),
                    color = Color(0xFF9A9AA0), fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (track?.isPlaying == true) Waveform(Color.White, scale = 1f)
        }
        Spacer(Modifier.height(12.dp))
        if (track != null) ProgressBar(track) else Spacer(Modifier.height(4.dp))
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBtn({ MediaRepo.controller?.transportControls?.skipToPrevious(); onInteract() }) {
                SkipIcon(next = false)
            }
            IconBtn({
                val tc = MediaRepo.controller?.transportControls
                if (track?.isPlaying == true) tc?.pause() else tc?.play()
                onInteract()
            }) { PlayPauseIcon(track?.isPlaying == true) }
            IconBtn({ MediaRepo.controller?.transportControls?.skipToNext(); onInteract() }) {
                SkipIcon(next = true)
            }
        }
    }
}

/**
 * Progress bar tanpa polling: satu animasi linear dari posisi sekarang sampai akhir lagu,
 * dimulai ulang hanya saat lagu/status play berubah. Nilainya dibaca di fase draw saja,
 * jadi tidak memicu recomposition. Hanya hidup saat panel musik terbuka.
 */
@Composable
private fun ProgressBar(track: TrackInfo) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(
        track.title, track.isPlaying, track.basePositionMs, track.baseTimeMs, track.durationMs
    ) {
        if (track.durationMs <= 0L) {
            progress.snapTo(0f)
            return@LaunchedEffect
        }
        val speed = track.speed.coerceAtLeast(0.1f)
        val now = if (track.isPlaying) {
            track.basePositionMs + ((SystemClock.elapsedRealtime() - track.baseTimeMs) * speed).toLong()
        } else track.basePositionMs
        val pos = now.coerceIn(0L, track.durationMs)
        progress.snapTo(pos.toFloat() / track.durationMs)
        if (track.isPlaying) {
            val remaining = ((track.durationMs - pos) / speed).toInt().coerceAtLeast(1)
            progress.animateTo(1f, tween(remaining, easing = LinearEasing))
        }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(Color(0x33FFFFFF))
            .drawBehind {
                drawRect(Color(0xCCFFFFFF), size = Size(size.width * progress.value, size.height))
            }
    )
}

// ───────────── Notifikasi & Charger ─────────────

@Composable
private fun NotifContent(n: NotifInfo) {
    Row(
        Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val icon = n.icon
        if (icon != null) {
            BitmapImage(icon, 44.dp, CircleShape)
        } else {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF2C2C2E)))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.widthIn(min = 120.dp, max = 250.dp)) {
            Text(n.appName, color = Color(0xFF9A9AA0), fontSize = 11.sp, maxLines = 1)
            Text(
                n.title, color = Color.White, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (n.text.isNotEmpty()) {
                Text(
                    n.text, color = Color(0xFFD1D1D6), fontSize = 13.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ChargeContent(level: Int) {
    var target by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) { target = level / 100f }
    val progress by animateFloatAsState(
        target,
        spring(dampingRatio = 0.9f, stiffness = 120f),
        label = "charge"
    )
    // Animasi denyut hanya ada selama panel ini tampil (±4 detik), lalu otomatis berhenti
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.45f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "bolt"
    )

    Row(
        Modifier.padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("⚡", fontSize = 26.sp, color = Color(0xFF30D158), modifier = Modifier.alpha(pulse))
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Mengisi daya", color = Color(0xFF9A9AA0), fontSize = 11.sp)
            Text("$level%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Box(
                Modifier
                    .width(120.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF2C2C2E))
                    .drawBehind {
                        drawRect(Color(0xFF30D158), size = Size(size.width * progress, size.height))
                    }
            )
        }
    }
}

// ───────────── Komponen kecil ─────────────

@Composable
private fun BitmapImage(bitmap: Bitmap, size: Dp, shape: Shape) {
    val img = remember(bitmap) { bitmap.asImageBitmap() }
    Image(
        bitmap = img,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(shape)
    )
}

@Composable
private fun IconBtn(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(56.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) { content() }
}

/** Ikon waveform statis (5 batang), tanpa animasi. */
@Composable
private fun Waveform(color: Color, scale: Float) {
    val heights = floatArrayOf(8f, 14f, 20f, 12f, 6f)
    Row(
        horizontalArrangement = Arrangement.spacedBy((2f * scale).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        heights.forEach {
            Box(
                Modifier
                    .width((3f * scale).dp)
                    .height((it * scale).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color)
            )
        }
    }
}

@Composable
private fun PlayPauseIcon(playing: Boolean) {
    Canvas(Modifier.size(30.dp)) {
        val w = size.width
        val h = size.height
        if (playing) {
            val bw = w * 0.22f
            drawRoundRect(Color.White, Offset(w * 0.18f, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(bw * 0.3f))
            drawRoundRect(Color.White, Offset(w * 0.60f, h * 0.12f), Size(bw, h * 0.76f), CornerRadius(bw * 0.3f))
        } else {
            val p = Path().apply {
                moveTo(w * 0.22f, h * 0.10f)
                lineTo(w * 0.86f, h * 0.50f)
                lineTo(w * 0.22f, h * 0.90f)
                close()
            }
            drawPath(p, Color.White)
        }
    }
}

@Composable
private fun SkipIcon(next: Boolean) {
    Canvas(Modifier.size(30.dp)) {
        val w = size.width
        val h = size.height
        val p = Path()
        fun tri(x0: Float, x1: Float) {
            if (next) {
                p.moveTo(x0, h * 0.2f); p.lineTo(x1, h * 0.5f); p.lineTo(x0, h * 0.8f)
            } else {
                p.moveTo(x1, h * 0.2f); p.lineTo(x0, h * 0.5f); p.lineTo(x1, h * 0.8f)
            }
            p.close()
        }
        tri(w * 0.05f, w * 0.50f)
        tri(w * 0.50f, w * 0.95f)
        drawPath(p, Color.White)
    }
}
