package com.example.island

import android.app.PendingIntent
import android.graphics.Bitmap
import android.media.session.MediaController
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow

data class TrackInfo(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val isPlaying: Boolean,
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,   // posisi saat state terakhir diperbarui
    val baseTimeMs: Long = 0L,       // elapsedRealtime saat posisi itu valid
    val speed: Float = 1f
)

data class NotifInfo(
    val appName: String,
    val title: String,
    val text: String,
    val icon: Bitmap?,
    val intent: PendingIntent?,
    val key: String = "",   // id percakapan (sbn.key): pesan susulan dari chat yang sama punya key sama
    val lines: List<String> = emptyList(),   // pesan-pesan baru (maks. 3), terlama -> terbaru
    val postedAt: Long = System.currentTimeMillis() // agar notifikasi identik tetap memicu ulang UI
)

data class ChargeInfo(
    val level: Int,
    val at: Long = System.currentTimeMillis()
)

/**
 * Penghubung antara MediaListenerService (sumber data) dan UI overlay.
 *
 * Notifikasi TIDAK lagi memakai satu slot StateFlow (last-wins). Alurnya:
 *   listener -> notifInbox (antrean, tidak ada yang hilang) -> NotifPresenter -> [notif] -> UI
 * [notif] hanya berisi notifikasi yang sedang ditampilkan.
 */
object MediaRepo {
    val track = MutableStateFlow<TrackInfo?>(null)
    val charge = MutableStateFlow<ChargeInfo?>(null)

    /** Notifikasi yang sedang tampil di kapsul (diatur oleh NotifPresenter, bukan oleh listener). */
    val notif = MutableStateFlow<NotifInfo?>(null)

    @Volatile var controller: MediaController? = null

    /** true selama OverlayService hidup; kalau false, notifikasi tidak ditampung. */
    @Volatile var overlayActive = false

    /** Antrean masuk. Jika penuh, yang paling lama dibuang. */
    val notifInbox = Channel<NotifInfo>(capacity = 32, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val dismissEvents = Channel<Unit>(Channel.CONFLATED)

    fun postNotif(info: NotifInfo) {
        if (overlayActive) notifInbox.trySend(info)
    }

    /** Dipanggil UI saat kapsul diketuk: tutup notifikasi yang tampil dan kosongkan antrean. */
    fun dismissNotifs() {
        dismissEvents.trySend(Unit)
    }
}
