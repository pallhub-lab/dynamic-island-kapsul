package com.example.island

import android.app.PendingIntent
import android.graphics.Bitmap
import android.media.session.MediaController
import kotlinx.coroutines.flow.MutableStateFlow

data class TrackInfo(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val isPlaying: Boolean
)

data class NotifInfo(
    val appName: String,
    val title: String,
    val text: String,
    val icon: Bitmap?,
    val intent: PendingIntent?,
    val postedAt: Long = System.currentTimeMillis() // agar notifikasi identik tetap memicu ulang UI
)

data class ChargeInfo(
    val level: Int,
    val at: Long = System.currentTimeMillis()
)

/** Penghubung antara MediaListenerService (sumber data) dan UI overlay. */
object MediaRepo {
    val track = MutableStateFlow<TrackInfo?>(null)
    val notif = MutableStateFlow<NotifInfo?>(null)
    val charge = MutableStateFlow<ChargeInfo?>(null)
    @Volatile var controller: MediaController? = null
}
