package com.example.island

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private var askedNotifPermission = false
    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        when {
            // 0) Izin menampilkan notifikasi foreground service (Android 13+)
            Build.VERSION.SDK_INT >= 33 && !askedNotifPermission &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED -> {
                askedNotifPermission = true
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            // 1) Izin tampil di atas aplikasi lain
            !Settings.canDrawOverlays(this) -> startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            // 2) Izin akses notifikasi (untuk membaca MediaSession & notifikasi)
            !NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName) ->
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            // 3) Semua izin siap
            else -> {
                startForegroundService(Intent(this, OverlayService::class.java))
                finish()
            }
        }
    }
}
