package com.example.island

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private var ready by mutableStateOf(false)
    private var running by mutableStateOf(false)
    private var askedNotifPermission = false
    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        IslandPrefs.load(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    SettingsScreen(
                        ready = ready,
                        running = running,
                        onToggle = { if (running) stopOverlay() else startOverlay() },
                        onAutoFit = { autoFit(toast = true) }
                    )
                }
            }
        }
    }

    private fun startOverlay() {
        startForegroundService(Intent(this, OverlayService::class.java))
        running = true
    }

    /** Area punch-hole / notch di tepi atas layar (API 29+), atau null jika tidak ada. */
    private fun topCutout(): Rect? {
        if (Build.VERSION.SDK_INT < 29) return null
        val cutout = window.decorView.rootWindowInsets?.displayCutout ?: return null
        val top = cutout.boundingRectTop
        return if (top.width() > 0 && top.height() > 0) top else cutout.boundingRects.firstOrNull()
    }

    /** Sesuaikan kapsul agar pas menutupi kamera. Dijalankan setelah window ter-attach. */
    private fun autoFit(toast: Boolean) {
        window.decorView.post {
            val r = topCutout()
            if (r == null) {
                if (toast) Toast.makeText(this, "Punch-hole tidak terdeteksi. Atur manual dengan slider.", Toast.LENGTH_LONG).show()
                return@post
            }
            IslandPrefs.set(IslandPrefs.fitToCutout(r, resources.displayMetrics))
            IslandPrefs.save(this)
            IslandPrefs.markFitted(this)
        }
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
        running = false
    }

    override fun onResume() {
        super.onResume()
        when {
            // 0) Izin menampilkan notifikasi foreground service (Android 13+)
            Build.VERSION.SDK_INT >= 33 && !askedNotifPermission &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED -> {
                askedNotifPermission = true
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            // 1) Izin tampil di atas aplikasi lain
            !Settings.canDrawOverlays(this) -> startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            // 2) Izin akses notifikasi (untuk membaca MediaSession & notifikasi)
            !NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName) ->
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            // 3) Semua izin siap
            else -> {
                ready = true
                if (!IslandPrefs.isFitted(this)) autoFit(toast = false)  // pertama kali: pas-kan ke kamera
                if (!running) startOverlay()
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    ready: Boolean,
    running: Boolean,
    onToggle: () -> Unit,
    onAutoFit: () -> Unit
) {
    val ctx = LocalContext.current
    val cfg by IslandPrefs.config.collectAsState()
    val screenW = LocalConfiguration.current.screenWidthDp.toFloat()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 32.dp)
    ) {
        Text("Dynamic Island", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            when {
                !ready -> "Menunggu izin… ikuti layar pengaturan yang terbuka."
                running -> "Aktif. Perubahan di bawah langsung terlihat di layar."
                else -> "Dihentikan."
            },
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(Modifier.height(16.dp))
        Button(onClick = onAutoFit, enabled = ready, modifier = Modifier.fillMaxWidth()) {
            Text("Sesuaikan otomatis ke kamera")
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Tutupi status bar saat notifikasi", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Kapsul notifikasi selebar layar sehingga ikon jam, sinyal, dan baterai tersembunyi rapi.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Switch(
                checked = cfg.coverStatusBar,
                onCheckedChange = {
                    IslandPrefs.set(cfg.copy(coverStatusBar = it))
                    IslandPrefs.save(ctx)
                }
            )
        }

        SettingSlider(
            "Posisi horizontal", cfg.xDp, -(screenW / 2f)..(screenW / 2f),
            onChange = { IslandPrefs.set(cfg.copy(xDp = it)) },
            onDone = { IslandPrefs.save(ctx) }
        )
        SettingSlider(
            "Posisi vertikal", cfg.yDp, 0f..300f,
            onChange = { IslandPrefs.set(cfg.copy(yDp = it)) },
            onDone = { IslandPrefs.save(ctx) }
        )
        SettingSlider(
            "Lebar kapsul", cfg.pillWidthDp, 60f..260f,
            onChange = { IslandPrefs.set(cfg.copy(pillWidthDp = it)) },
            onDone = { IslandPrefs.save(ctx) }
        )
        SettingSlider(
            "Tinggi kapsul", cfg.pillHeightDp, 20f..60f,
            onChange = { IslandPrefs.set(cfg.copy(pillHeightDp = it)) },
            onDone = { IslandPrefs.save(ctx) }
        )

        Spacer(Modifier.height(12.dp))
        Text(
            "Tips: tekan lama kapsul di layar lalu geser untuk memindahkannya langsung.",
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onToggle, enabled = ready, modifier = Modifier.weight(1f)) {
                Text(if (running) "Hentikan" else "Mulai")
            }
            OutlinedButton(
                onClick = {
                    IslandPrefs.set(IslandConfig())
                    IslandPrefs.save(ctx)
                },
                modifier = Modifier.weight(1f)
            ) { Text("Reset") }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Pengaturan baterai (agar tidak dimatikan sistem)") }
    }
}

@Composable
private fun SettingSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onDone: () -> Unit
) {
    Column(Modifier.padding(top = 16.dp)) {
        Text("$label: ${value.roundToInt()} dp", style = MaterialTheme.typography.bodyMedium)
        Slider(
            value = value.coerceIn(range),
            onValueChange = onChange,
            valueRange = range,
            onValueChangeFinished = onDone
        )
    }
}
