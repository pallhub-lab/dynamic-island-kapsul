package com.example.island

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.graphics.Bitmap
import android.os.Bundle
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.roundToInt

/**
 * NotificationListenerService dipakai karena izin inilah yang
 * mengizinkan aplikasi membaca MediaSession aktif (Spotify, YT Music, dll).
 */
class MediaListenerService : NotificationListenerService() {

    private lateinit var msm: MediaSessionManager
    private lateinit var component: ComponentName
    private var current: MediaController? = null

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() = pick(safeSessions())
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    // Aplikasi yang TIDAK ingin ditampilkan di kapsul (tambahkan nama paket sesuai selera)
    private val labelCache = HashMap<String, String>()
    // Tanda tangan terakhir PER notifikasi (key), bukan satu global
    private val lastSigs = HashMap<String, String>()
    private val lastMsgTime = HashMap<String, Long>()

    private val blockedApps = setOf("android", "com.android.systemui", "com.google.android.gms")

    // Kategori notifikasi yang bukan "pesan masuk"
    private val skipCategories = setOf(
        Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS,
        Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM,
        Notification.CATEGORY_STATUS
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg == packageName || pkg in blockedApps) return
        val n = sbn.notification

        // Abaikan ringkasan grup, notifikasi menetap, dan service latar belakang
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return
        val cat = n.category
        if (cat != null && cat in skipCategories) return
        // Notifikasi pemutar musik ditangani fitur media, bukan di sini
        if (n.extras.containsKey(Notification.EXTRA_MEDIA_SESSION)) return

        // Abaikan notifikasi senyap (importance rendah)
        val ranking = NotificationListenerService.Ranking()
        if (currentRanking.getRanking(sbn.key, ranking) &&
            ranking.importance < NotificationManager.IMPORTANCE_DEFAULT
        ) return

        val appName = labelCache.getOrPut(pkg) {
            try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) { pkg }
        }

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val plainText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val msgs = readMessages(extras)

        // Lewati HANYA kiriman ulang yang sama persis. Waktu kirim ikut dibandingkan, sehingga
        // dua pesan berisi teks sama ("ok", "ok") tetap dihitung dua kali.
        val sig = "${sbn.postTime}|${n.`when`}|$title|$plainText|${msgs.size}|${msgs.lastOrNull()?.time}"
        if (lastSigs[sbn.key] == sig) return
        if (lastSigs.size > 100) lastSigs.clear()
        lastSigs[sbn.key] = sig

        // Ambil pesan BARU saja (maks. 3). Notifikasi chat menyimpan riwayat pesan; kita bandingkan
        // dengan waktu pesan terakhir yang sudah ditampilkan agar pesan lama tidak muncul lagi.
        val lines: List<String> = if (msgs.isNotEmpty()) {
            val seen = lastMsgTime[sbn.key]
            val fresh = if (seen == null) msgs.takeLast(1)
            else msgs.filter { it.time > seen }.ifEmpty { msgs.takeLast(1) }
            if (lastMsgTime.size > 100) lastMsgTime.clear()
            lastMsgTime[sbn.key] = msgs.maxOf { it.time }
            fresh.takeLast(3).map {
                if (!it.sender.isNullOrEmpty() && it.sender != title) "${it.sender}: ${it.text}" else it.text
            }
        } else {
            listOf(plainText).filter { it.isNotEmpty() }
        }

        // Foto pengirim (large icon) kalau ada, jika tidak pakai small icon aplikasi
        val icon = try {
            (n.getLargeIcon() ?: n.smallIcon)?.loadDrawable(this)?.toBitmap(96, 96)
        } catch (e: Exception) { null }

        MediaRepo.postNotif(
            NotifInfo(
                appName = appName,
                title = title,
                text = lines.lastOrNull().orEmpty(),
                icon = icon,
                intent = n.contentIntent,
                key = sbn.key,
                lines = lines
            )
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        lastSigs.remove(sbn.key)
        lastMsgTime.remove(sbn.key)   // chat dibuka/dihapus: pesan berikutnya dengan key sama harus tampil lagi
    }

    private class Msg(val sender: String?, val text: String, val time: Long)

    /** Semua pesan dari notifikasi bergaya percakapan (lama -> baru). */
    @Suppress("DEPRECATION")
    private fun readMessages(extras: Bundle): List<Msg> = try {
        extras.getParcelableArray(Notification.EXTRA_MESSAGES)?.mapNotNull { p ->
            val b = p as? Bundle ?: return@mapNotNull null
            val t = b.getCharSequence("text")?.toString() ?: return@mapNotNull null
            Msg(b.getCharSequence("sender")?.toString(), t, b.getLong("time"))
        } ?: emptyList()
    } catch (e: Exception) { emptyList() }

    override fun onListenerConnected() {
        msm = getSystemService(MediaSessionManager::class.java)
        component = ComponentName(this, MediaListenerService::class.java)
        msm.addOnActiveSessionsChangedListener(sessionsListener, component)
        pick(safeSessions())
    }

    override fun onListenerDisconnected() {
        if (::msm.isInitialized) msm.removeOnActiveSessionsChangedListener(sessionsListener)
        current?.unregisterCallback(controllerCallback)
        current = null
        MediaRepo.controller = null
        MediaRepo.track.value = null
        artSrc = null
        artScaled = null
        lastSigs.clear()
        lastMsgTime.clear()
        labelCache.clear()
    }

    private fun safeSessions(): List<MediaController>? =
        try { msm.getActiveSessions(component) } catch (e: SecurityException) { null }

    /** Pilih sesi yang sedang play; kalau tidak ada, ambil sesi pertama. */
    private fun pick(list: List<MediaController>?) {
        val chosen = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()

        if (chosen?.sessionToken == current?.sessionToken && chosen != null) return

        current?.unregisterCallback(controllerCallback)
        current = chosen
        MediaRepo.controller = chosen
        chosen?.registerCallback(controllerCallback)
        publish()
    }

    // Cover album diperkecil (hemat RAM) dan di-cache supaya tidak diproses ulang
    private var artSrc: Bitmap? = null
    private var artScaled: Bitmap? = null

    private fun scaledArt(src: Bitmap?): Bitmap? {
        if (src == null) return null
        if (src === artSrc) return artScaled
        val scale = 160f / maxOf(src.width, src.height)
        val out = if (scale >= 1f) src else Bitmap.createScaledBitmap(
            src,
            (src.width * scale).roundToInt().coerceAtLeast(1),
            (src.height * scale).roundToInt().coerceAtLeast(1),
            true
        )
        artSrc = src
        artScaled = out
        return out
    }

    private fun publish() {
        val c = current
        val md = c?.metadata
        if (c == null || md == null) {
            MediaRepo.track.value = null
            return
        }
        val art = scaledArt(
            md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        )

        val ps = c.playbackState
        MediaRepo.track.value = TrackInfo(
            title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Tanpa judul",
            artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
            art = art,
            isPlaying = ps?.state == PlaybackState.STATE_PLAYING,
            durationMs = md.getLong(MediaMetadata.METADATA_KEY_DURATION),
            basePositionMs = ps?.position ?: 0L,
            baseTimeMs = ps?.lastPositionUpdateTime ?: 0L,
            speed = ps?.playbackSpeed ?: 1f
        )
    }
}
