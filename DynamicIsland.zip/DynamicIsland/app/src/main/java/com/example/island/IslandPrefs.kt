package com.example.island

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/** Semua ukuran dalam dp, supaya posisi konsisten di berbagai layar. */
data class IslandConfig(
    val xDp: Float = 0f,          // geser dari tengah (negatif = kiri, positif = kanan)
    val yDp: Float = 8f,          // jarak dari tepi atas layar
    val pillWidthDp: Float = 110f,
    val pillHeightDp: Float = 32f
)

object IslandPrefs {
    val config = MutableStateFlow(IslandConfig())

    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("island", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val d = IslandConfig()
        val s = sp(ctx)
        config.value = IslandConfig(
            xDp = s.getFloat("x", d.xDp),
            yDp = s.getFloat("y", d.yDp),
            pillWidthDp = s.getFloat("w", d.pillWidthDp),
            pillHeightDp = s.getFloat("h", d.pillHeightDp)
        )
    }

    /** Ubah live (service langsung menerapkan), tanpa menulis ke disk. */
    fun set(cfg: IslandConfig) { config.value = cfg }

    fun save(ctx: Context) {
        val c = config.value
        sp(ctx).edit()
            .putFloat("x", c.xDp).putFloat("y", c.yDp)
            .putFloat("w", c.pillWidthDp).putFloat("h", c.pillHeightDp)
            .apply()
    }
}
