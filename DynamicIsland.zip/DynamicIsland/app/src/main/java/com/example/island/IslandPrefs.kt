package com.example.island

import android.content.Context
import android.graphics.Rect
import android.util.DisplayMetrics
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.max

/** Semua ukuran dalam dp, supaya posisi konsisten di berbagai layar. */
data class IslandConfig(
    val xDp: Float = 0f,          // geser dari tengah (negatif = kiri, positif = kanan)
    val yDp: Float = 8f,          // jarak dari tepi atas layar
    val pillWidthDp: Float = 110f,
    val pillHeightDp: Float = 32f
)

object IslandPrefs {
    val config = MutableStateFlow(IslandConfig())

    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("island", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val d = IslandConfig()
        val s = sp(ctx)
        config.value = IslandConfig(
            xDp = s.getFloat("x", d.xDp),
            yDp = s.getFloat("y", d.yDp),
            pillWidthDp = s.getFloat("w", d.pillWidthDp),
            pillHeightDp = s.getFloat("h", d.pillHeightDp)
        )
    }

    /** Ubah live (service langsung menerapkan), tanpa menulis ke disk. */
    fun set(cfg: IslandConfig) { config.value = cfg }

    fun save(ctx: Context) {
        val c = config.value
        sp(ctx).edit()
            .putFloat("x", c.xDp).putFloat("y", c.yDp)
            .putFloat("w", c.pillWidthDp).putFloat("h", c.pillHeightDp)
            .apply()
    }

    fun isFitted(ctx: Context) = sp(ctx).getBoolean("fitted", false)
    fun markFitted(ctx: Context) { sp(ctx).edit().putBoolean("fitted", true).apply() }

    /**
     * Hitung posisi & ukuran kapsul agar PAS menutupi punch-hole.
     * Rasio kapsul dibuat ~3,4 : 1 seperti Dynamic Island iPhone asli.
     */
    fun fitToCutout(r: Rect, dm: DisplayMetrics): IslandConfig {
        val d = dm.density
        val pad = 4f
        val holeW = r.width() / d
        val holeH = r.height() / d
        val height = holeH + pad * 2
        val width = max(holeW + pad * 2 + 8f, height * 3.4f)
        return IslandConfig(
            // Kamera hampir di tengah -> kunci tepat di tengah (tanpa geser samping)
            xDp = ((r.centerX() - dm.widthPixels / 2f) / d).let { if (kotlin.math.abs(it) < 12f) 0f else it },
            yDp = max(0f, r.top / d - pad),
            pillWidthDp = width,
            pillHeightDp = height
        )
    }
}
