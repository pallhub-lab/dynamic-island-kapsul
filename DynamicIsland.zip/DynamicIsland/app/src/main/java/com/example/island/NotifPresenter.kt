package com.example.island

import android.os.SystemClock
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.withTimeoutOrNull

private const val SHOW_MS = 5000L           // lama tampil jika tidak ada antrean
private const val SHOW_QUEUED_MS = 2500L    // lama tampil jika masih ada pesan lain menunggu
private const val MIN_SHOW_MS = 1800L       // minimal tiap pesan terbaca
private const val MAX_QUEUE = 5
private const val MAX_LINES = 3

private object Dismiss

/**
 * Menampilkan notifikasi satu per satu dari MediaRepo.notifInbox.
 *  - Pesan susulan dari chat yang SAMA  -> teks di kapsul diperbarui di tempat, timer diulang.
 *  - Pesan dari chat/aplikasi LAIN      -> masuk antrean, tampil bergantian.
 * Seluruhnya suspend (receive / select / timeout): tidak ada polling dan tidak ada
 * pemakaian CPU saat tidak ada notifikasi.
 */
suspend fun presentNotifications() {
    val inbox = MediaRepo.notifInbox
    val dismiss = MediaRepo.dismissEvents

    // Buang sisa notifikasi lama yang menumpuk saat overlay belum jalan
    while (inbox.tryReceive().isSuccess) { /* kosongkan */ }
    dismiss.tryReceive()

    val queue = ArrayDeque<NotifInfo>()

    while (true) {
        var current = queue.removeFirstOrNull() ?: inbox.receive()   // menunggu tanpa polling
        MediaRepo.notif.value = current

        var shownAt = SystemClock.elapsedRealtime()
        var deadline = shownAt + if (queue.isEmpty()) SHOW_MS else SHOW_QUEUED_MS
        var dismissed = false

        while (true) {
            val wait = deadline - SystemClock.elapsedRealtime()
            if (wait <= 0L) break

            val event: Any = withTimeoutOrNull(wait) {
                select<Any> {
                    inbox.onReceive { it }
                    dismiss.onReceive { Dismiss }
                }
            } ?: break   // waktu tampil habis

            if (event === Dismiss) {
                queue.clear()
                dismissed = true
                break
            }

            val incoming = event as NotifInfo
            val now = SystemClock.elapsedRealtime()
            if (incoming.key == current.key) {
                // Pesan susulan dari chat yang sama: perbarui teks langsung
                // Gabungkan: pesan lama tetap terbaca, pesan baru ditambahkan (maks. 3 baris)
                current = incoming.copy(lines = (current.lines + incoming.lines).takeLast(MAX_LINES))
                MediaRepo.notif.value = current
                shownAt = now
                deadline = now + if (queue.isEmpty()) SHOW_MS else SHOW_QUEUED_MS
            } else {
                // Chat lain: antre (pesan lama dari chat yang sama di antrean diganti yang terbaru)
                val idx = queue.indexOfFirst { it.key == incoming.key }
                if (idx >= 0) {
                    queue[idx] = incoming.copy(lines = (queue[idx].lines + incoming.lines).takeLast(MAX_LINES))
                } else {
                    if (queue.size >= MAX_QUEUE) queue.removeFirst()
                    queue.addLast(incoming)
                }
                // Percepat pesan yang sedang tampil, tapi beri waktu baca minimal
                deadline = maxOf(shownAt + MIN_SHOW_MS, minOf(deadline, now + SHOW_QUEUED_MS))
            }
        }

        // Jika masih ada antrean, langsung ganti ke pesan berikutnya tanpa menutup kapsul
        if (queue.isEmpty() || dismissed) MediaRepo.notif.value = null
    }
}
