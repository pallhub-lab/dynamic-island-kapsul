package com.example.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.*
import androidx.savedstate.*
import kotlinx.coroutines.*
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

private const val EXPANDED_W_DP = 360f
private const val EXPANDED_H_DP = 120f

/**
 * Pembungkus ComposeView: tekan lama kapsul lalu geser untuk memindahkan posisinya.
 * Menggunakan koordinat layar (rawX/rawY) agar tidak "bergetar" saat window ikut bergerak.
 */
class DragLayout(context: Context) : FrameLayout(context) {
    var onDragStart: () -> Unit = {}
    var onDragMove: (Float, Float) -> Unit = { _, _ -> }
    var onDragEnd: () -> Unit = {}

    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val longPress = Runnable {
        dragging = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        onDragStart()
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                dragging = false
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                    removeCallbacks(longPress)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (dragging) {
                    dragging = false
                    onDragEnd()
                    return true
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!dragging) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> onDragMove(e.rawX - downX, e.rawY - downY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                onDragEnd()
            }
        }
        return true
    }
}

class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    override val viewModelStore = ViewModelStore()
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateController.savedStateRegistry

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private var root: DragLayout? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var cfg = IslandConfig()
    private var windowBig = false
    private var dragStartX = 0
    private var dragStartY = 0

    private var wasCharging: Boolean? = null
    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 /
                i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            // Munculkan hanya saat charger BARU dicolokkan
            if (wasCharging == false && charging) MediaRepo.charge.value = ChargeInfo(level)
            wasCharging = charging
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        startForeground(1, buildNotification())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        IslandPrefs.load(this)
        cfg = IslandPrefs.config.value
        showIsland()

        // Terapkan perubahan posisi/ukuran dari layar pengaturan secara live
        scope.launch {
            IslandPrefs.config.collect {
                cfg = it
                applyLayout()
            }
        }

        ContextCompat.registerReceiver(
            this, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).roundToInt()

    /**
     * Ukuran window dibuat TETAP (bukan WRAP_CONTENT), lalu hanya diganti saat
     * mode pill <-> expanded. Animasi kapsul terjadi di dalam window sehingga
     * tidak ada relayout window per frame (penyebab utama lag sebelumnya).
     */
    private fun applyLayout() {
        if (!::params.isInitialized) return
        val dm = resources.displayMetrics
        if (windowBig) {
            params.width = min(dp(EXPANDED_W_DP), dm.widthPixels - dp(16f))
            params.height = dp(EXPANDED_H_DP)
        } else {
            params.width = dp(cfg.pillWidthDp)
            params.height = dp(cfg.pillHeightDp)
        }
        params.x = dp(cfg.xDp)
        params.y = dp(cfg.yDp)
        root?.let {
            try { wm.updateViewLayout(it, params) } catch (_: Exception) {}
        }
    }

    private fun onWindowBig(big: Boolean) {
        if (windowBig != big) {
            windowBig = big
            applyLayout()
        }
    }

    private fun showIsland() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                // Tanpa flag ini window overlay dirender via software (sangat lag)
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            // Izinkan menggambar sampai area punch-hole / notch
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        applyLayout()

        val compose = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setContent { IslandUI(onWindowBig = ::onWindowBig) }
        }

        val layout = DragLayout(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            addView(
                compose,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            onDragStart = {
                dragStartX = params.x
                dragStartY = params.y
            }
            onDragMove = { dx, dy ->
                params.x = dragStartX + dx.roundToInt()
                params.y = (dragStartY + dy.roundToInt()).coerceAtLeast(0)
                try { wm.updateViewLayout(this, params) } catch (_: Exception) {}
            }
            onDragEnd = {
                val d = resources.displayMetrics.density
                IslandPrefs.set(cfg.copy(xDp = params.x / d, yDp = params.y / d))
                IslandPrefs.save(this@OverlayService)
            }
        }
        wm.addView(layout, params)
        root = layout
    }

    private fun buildNotification(): Notification {
        val chId = "island"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(chId, "Dynamic Island", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, chId)
            .setContentTitle("Dynamic Island aktif")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
        super.onDestroy()
    }
}

// ───────────────────────────── UI ─────────────────────────────

@Composable
fun IslandUI(onWindowBig: (Boolean) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val track by MediaRepo.track.collectAsState()
    val notif by MediaRepo.notif.collectAsState()
    val charge by MediaRepo.charge.collectAsState()
    val cfg by IslandPrefs.config.collectAsState()
    val n = notif
    val c = charge

    LaunchedEffect(n) {
        if (n != null) {
            delay(5000)
            MediaRepo.notif.value = null
        }
    }
    LaunchedEffect(c) {
        if (c != null) {
            delay(4000)
            MediaRepo.charge.value = null
        }
    }

    val big = expanded || n != null || c != null

    // Window membesar langsung, mengecil setelah animasi selesai
    LaunchedEffect(big) {
        if (big) {
            onWindowBig(true)
        } else {
            delay(400)
            onWindowBig(false)
        }
    }

    val corner by animateDpAsState(
        if (big) 32.dp else (cfg.pillHeightDp / 2f).dp,
        label = "corner"
    )

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Box(
            Modifier
                .animateContentSize()
                .clip(RoundedCornerShape(corner))
                .background(Color.Black)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    if (n != null) {
                        try { n.intent?.send() } catch (_: Exception) {}
                        MediaRepo.notif.value = null
                    } else if (c != null) {
                        MediaRepo.charge.value = null
                    } else {
                        expanded = !expanded
                    }
                }
        ) {
            when {
                n != null -> Box(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                    NotifContent(n)
                }
                c != null -> Box(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                    ChargeContent(c.level)
                }
                expanded -> Box(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                    ExpandedContent(track)
                }
                else -> PillContent(track, cfg)
            }
        }
    }
}

@Composable
private fun BitmapImage(bitmap: Bitmap, size: Dp, shape: Shape) {
    val img = remember(bitmap) { bitmap.asImageBitmap() }
    Image(
        bitmap = img,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(shape)
    )
}

@Composable
private fun PillContent(track: TrackInfo?, cfg: IslandConfig) {
    val artSize = (cfg.pillHeightDp - 10f).coerceAtLeast(10f).dp
    // Sisi kiri & kanan dipakai, bagian tengah dibiarkan kosong untuk kamera
    Row(
        Modifier
            .size(cfg.pillWidthDp.dp, cfg.pillHeightDp.dp)
            .padding(horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val art = track?.art
        if (art != null) BitmapImage(art, artSize, CircleShape) else Spacer(Modifier.size(artSize))
        if (track?.isPlaying == true) {
            Text("♪", color = Color(0xFF1DB954), fontSize = 14.sp)
        } else {
            Spacer(Modifier.size(artSize))
        }
    }
}

@Composable
private fun MediaBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 18.sp)
    }
}

@Composable
private fun ExpandedContent(track: TrackInfo?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        val art = track?.art
        if (art != null) {
            BitmapImage(art, 52.dp, RoundedCornerShape(12.dp))
        } else {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(Color.DarkGray))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.widthIn(min = 80.dp, max = 110.dp)) {
            Text(
                track?.title ?: "Tidak ada musik",
                color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                track?.artist ?: "",
                color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        val tc = MediaRepo.controller?.transportControls
        MediaBtn("⏮") { tc?.skipToPrevious() }
        MediaBtn(if (track?.isPlaying == true) "⏸" else "▶") {
            if (track?.isPlaying == true) tc?.pause() else tc?.play()
        }
        MediaBtn("⏭") { tc?.skipToNext() }
    }
}

@Composable
private fun NotifContent(n: NotifInfo) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        val icon = n.icon
        if (icon != null) {
            BitmapImage(icon, 44.dp, CircleShape)
        } else {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color.DarkGray))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.widthIn(min = 120.dp, max = 230.dp)) {
            Text(n.appName, color = Color.Gray, fontSize = 11.sp, maxLines = 1)
            Text(
                n.title, color = Color.White, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (n.text.isNotEmpty()) {
                Text(
                    n.text, color = Color.LightGray, fontSize = 13.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ChargeContent(level: Int) {
    var target by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) { target = level / 100f }
    val progress by animateFloatAsState(target, tween(900), label = "charge")

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "bolt"
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("⚡", fontSize = 26.sp, color = Color(0xFF30D158), modifier = Modifier.alpha(pulse))
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Mengisi daya", color = Color.Gray, fontSize = 11.sp)
            Text("$level%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Box(
                Modifier.width(110.dp).height(6.dp)
                    .clip(RoundedCornerShape(3.dp)).background(Color.DarkGray)
            ) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(progress)
                        .background(Color(0xFF30D158))
                )
            }
        }
    }
}
