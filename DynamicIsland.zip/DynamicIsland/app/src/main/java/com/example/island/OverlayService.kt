package com.example.island

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.lifecycle.*
import androidx.savedstate.*

class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    override val viewModelStore = ViewModelStore()
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateController.savedStateRegistry

    private lateinit var wm: WindowManager
    private var composeView: ComposeView? = null

    private var wasCharging: Boolean? = null

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 /
                i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            // Munculkan hanya saat charger BARU dicolokkan (bukan saat service baru start)
            if (wasCharging == false && charging) MediaRepo.charge.value = ChargeInfo(level)
            wasCharging = charging
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        startForeground(1, buildNotification())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showIsland()
        ContextCompat.registerReceiver(
            this, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun showIsland() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 12 // sesuaikan dengan posisi punch-hole HP kamu (px)
        }

        composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setContent { IslandUI() }
        }
        wm.addView(composeView, params)
    }

    private fun buildNotification(): Notification {
        val chId = "island"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(chId, "Dynamic Island", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, chId)
            .setContentTitle("Dynamic Island aktif")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    override fun onDestroy() {
        unregisterReceiver(batteryReceiver)
        composeView?.let { wm.removeView(it) }
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
        super.onDestroy()
    }
}

@Composable
fun IslandUI() {
    var expanded by remember { mutableStateOf(false) }
    val track by MediaRepo.track.collectAsState()
    val notif by MediaRepo.notif.collectAsState()
    val n = notif
    val charge by MediaRepo.charge.collectAsState()
    val c = charge

    LaunchedEffect(c) {
        if (c != null) {
            delay(4000)
            MediaRepo.charge.value = null
        }
    }

    // Notifikasi tampil 5 detik lalu kapsul kembali normal
    LaunchedEffect(n) {
        if (n != null) {
            delay(5000)
            MediaRepo.notif.value = null
        }
    }

    val big = expanded || n != null || c != null

    Box(
        modifier = Modifier
            .animateContentSize()
            .clip(RoundedCornerShape(if (big) 32.dp else 50.dp))
            .background(Color.Black)
            .clickable {
                if (n != null) {
                    // Ketuk notifikasi -> buka chat/aplikasinya
                    try { n.intent?.send() } catch (_: Exception) {}
                    MediaRepo.notif.value = null
                } else if (c != null) {
                    MediaRepo.charge.value = null
                } else {
                    expanded = !expanded
                }
            }
            .padding(
                horizontal = if (big) 20.dp else 14.dp,
                vertical = if (big) 14.dp else 6.dp
            )
    ) {
        when {
            n != null -> NotifContent(n)
            c != null -> ChargeContent(c.level)
            expanded -> ExpandedContent(track)
            else -> PillContent(track)
        }
    }
}

@Composable
private fun ChargeContent(level: Int) {
    var target by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) { target = level / 100f }
    val progress by animateFloatAsState(target, tween(900), label = "charge")

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "bolt"
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("⚡", fontSize = 26.sp, color = Color(0xFF30D158), modifier = Modifier.alpha(pulse))
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Mengisi daya", color = Color.Gray, fontSize = 11.sp)
            Text("$level%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Box(
                Modifier.width(110.dp).height(6.dp)
                    .clip(RoundedCornerShape(3.dp)).background(Color.DarkGray)
            ) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(progress)
                        .background(Color(0xFF30D158))
                )
            }
        }
    }
}

@Composable
private fun NotifContent(n: NotifInfo) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (n.icon != null) {
            Image(
                bitmap = n.icon.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(44.dp).clip(CircleShape)
            )
        } else {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color.DarkGray))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.widthIn(min = 120.dp, max = 230.dp)) {
            Text(n.appName, color = Color.Gray, fontSize = 11.sp)
            Text(
                n.title, color = Color.White, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (n.text.isNotEmpty()) {
                Text(
                    n.text, color = Color.LightGray, fontSize = 13.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun PillContent(track: TrackInfo?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (track?.art != null) {
            Image(
                bitmap = track.art.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(20.dp).clip(CircleShape)
            )
            Spacer(Modifier.width(24.dp)) // ruang untuk area kamera
            if (track.isPlaying) Text("♪", color = Color(0xFF1DB954))
        } else {
            Spacer(Modifier.width(60.dp))
        }
    }
}

@Composable
private fun ExpandedContent(track: TrackInfo?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (track?.art != null) {
            Image(
                bitmap = track.art.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp))
            )
        } else {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(Color.DarkGray))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.widthIn(min = 100.dp, max = 150.dp)) {
            Text(
                track?.title ?: "Tidak ada musik",
                color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                track?.artist ?: "",
                color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        val tc = MediaRepo.controller?.transportControls
        TextButton({ tc?.skipToPrevious() }) { Text("⏮") }
        TextButton({
            if (track?.isPlaying == true) tc?.pause() else tc?.play()
        }) { Text(if (track?.isPlaying == true) "⏸" else "▶") }
        TextButton({ tc?.skipToNext() }) { Text("⏭") }
    }
}
