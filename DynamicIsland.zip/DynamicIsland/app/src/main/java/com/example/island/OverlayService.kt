package com.example.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.lifecycle.*
import androidx.savedstate.*
import kotlinx.coroutines.*
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

private const val EXPANDED_W_DP = 376f

/**
 * Pembungkus ComposeView: tekan lama kapsul lalu geser untuk memindahkan posisinya.
 * Memakai koordinat layar (rawX/rawY) agar tidak "bergetar" saat window ikut bergerak.
 * Timer long-press hanya berjalan saat jari menyentuh kapsul.
 */
class DragLayout(context: Context) : FrameLayout(context) {
    var onDragStart: () -> Unit = {}
    var onDragMove: (Float, Float) -> Unit = { _, _ -> }
    var onDragEnd: () -> Unit = {}

    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val longPress = Runnable {
        dragging = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        onDragStart()
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                dragging = false
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                    removeCallbacks(longPress)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (dragging) {
                    dragging = false
                    onDragEnd()
                    return true
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!dragging) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> onDragMove(e.rawX - downX, e.rawY - downY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                onDragEnd()
            }
        }
        return true
    }
}

/**
 * Service overlay. Seluruhnya event-driven:
 *  - musik & notifikasi  -> callback MediaListenerService
 *  - charger             -> broadcast ACTION_POWER_CONNECTED (hanya saat dicolok)
 *  - posisi/ukuran       -> StateFlow dari IslandPrefs
 * Tidak ada polling, Handler berulang, ataupun WakeLock.
 */
class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    override val viewModelStore = ViewModelStore()
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateController.savedStateRegistry

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private var root: DragLayout? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var cfg = IslandConfig()
    private var windowHeightDp = 0f          // 0 = window seukuran pill
    private var dragStartX = 0
    private var dragStartY = 0

    // Hanya menyala saat kabel/charger dicolokkan (bukan tiap perubahan persen baterai)
    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            MediaRepo.charge.value = ChargeInfo(level)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        startForeground(1, buildNotification())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        IslandPrefs.load(this)
        cfg = IslandPrefs.config.value
        showIsland()
        updateOrientation()

        // Terapkan perubahan posisi/ukuran dari layar pengaturan secara live
        scope.launch {
            IslandPrefs.config.collect {
                cfg = it
                applyLayout()
            }
        }

        // Penyaji notifikasi: satu coroutine yang tidur sampai ada notifikasi masuk
        MediaRepo.overlayActive = true
        scope.launch { presentNotifications() }

        ContextCompat.registerReceiver(
            this, powerReceiver, IntentFilter(Intent.ACTION_POWER_CONNECTED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).roundToInt()

    /**
     * Ukuran window dibuat TETAP (bukan WRAP_CONTENT) dan hanya diganti saat berpindah mode.
     * Animasi spring terjadi di dalam window sehingga tidak ada relayout window per frame.
     */
    private fun applyLayout() {
        if (!::params.isInitialized) return
        val dm = resources.displayMetrics
        if (windowHeightDp > 0f) {
            params.width = min(dp(EXPANDED_W_DP), dm.widthPixels - dp(16f))
            params.height = dp(windowHeightDp)
            // Pastikan panel besar tidak keluar layar jika kamera berada di pojok
            val maxShift = ((dm.widthPixels - params.width) / 2).coerceAtLeast(0)
            params.x = dp(cfg.xDp).coerceIn(-maxShift, maxShift)
        } else {
            params.width = dp(cfg.pillWidthDp)
            params.height = dp(cfg.pillHeightDp)
            params.x = dp(cfg.xDp)
        }
        params.y = dp(cfg.yDp)
        root?.let {
            try { wm.updateViewLayout(it, params) } catch (_: Exception) {}
        }
    }

    private fun onWindowHeight(heightDp: Float) {
        if (windowHeightDp != heightDp) {
            windowHeightDp = heightDp
            applyLayout()
        }
    }

    /** Posisi kamera berubah saat landscape; kapsul disembunyikan agar tidak salah tempat. */
    private fun updateOrientation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        root?.visibility = if (landscape) View.GONE else View.VISIBLE
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateOrientation()
        applyLayout()
    }

    private fun showIsland() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                // Tanpa flag ini window overlay dirender via software (sangat lag)
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            // Izinkan menggambar sampai area punch-hole / notch
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        applyLayout()

        val compose = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setContent { IslandUI(onWindowHeight = ::onWindowHeight) }
        }

        val layout = DragLayout(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            addView(
                compose,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            onDragStart = {
                dragStartX = params.x
                dragStartY = params.y
            }
            onDragMove = { dx, dy ->
                params.x = dragStartX + dx.roundToInt()
                params.y = (dragStartY + dy.roundToInt()).coerceAtLeast(0)
                try { wm.updateViewLayout(this, params) } catch (_: Exception) {}
            }
            onDragEnd = {
                val d = resources.displayMetrics.density
                IslandPrefs.set(cfg.copy(xDp = params.x / d, yDp = params.y / d))
                IslandPrefs.save(this@OverlayService)
            }
        }
        wm.addView(layout, params)
        root = layout
    }

    private fun buildNotification(): Notification {
        val chId = "island"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(chId, "Dynamic Island", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, chId)
            .setContentTitle("Dynamic Island aktif")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    override fun onDestroy() {
        MediaRepo.overlayActive = false
        scope.cancel()
        MediaRepo.notif.value = null
        try { unregisterReceiver(powerReceiver) } catch (_: Exception) {}
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
        super.onDestroy()
    }
}
