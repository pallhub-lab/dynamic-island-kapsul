package com.example.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.lifecycle.*
import androidx.savedstate.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

private const val BIG_W_DP = 360f
private const val BIG_H_DP = 176f
private const val IDLE_ALPHA = 0.79f      // <= 0,8 : Android 12+ tetap meneruskan sentuhan lewat window ini
private const val COLLAPSE_MS = 700L      // waktu spring menciut sebelum kembali ke jendela pill
private const val HANDOVER_MS = 60L       // tumpang tindih singkat dua jendela (identik, tidak terlihat)
private const val BASE_FLAGS =
    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
        // Tanpa flag ini window overlay dirender via software (sangat lag)
        WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED

/**
 * Pembungkus ComposeView: tekan lama kapsul lalu geser untuk memindahkan posisinya.
 * Memakai koordinat layar (rawX/rawY) agar tidak "bergetar" saat window ikut bergerak.
 */
class DragLayout(context: Context) : FrameLayout(context) {
    var onDragStart: () -> Unit = {}
    var onDragMove: (Float, Float) -> Unit = { _, _ -> }
    var onDragEnd: () -> Unit = {}

    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private val longPress = Runnable {
        dragging = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        onDragStart()
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                dragging = false
                postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                    removeCallbacks(longPress)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (dragging) {
                    dragging = false
                    onDragEnd()
                    return true
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!dragging) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> onDragMove(e.rawX - downX, e.rawY - downY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                onDragEnd()
            }
        }
        return true
    }
}

/**
 * Service overlay dengan DUA jendela yang frame-nya TIDAK PERNAH berubah saat animasi:
 *
 *  P (pill)  : seukuran pill, selalu aktif & bisa disentuh. Menggambar kapsul saat idle.
 *  E (besar) : 360x176 dp. Saat idle: tembus sentuhan (NOT_TOUCHABLE, alpha 0,79) dan kosong.
 *              Saat ada notifikasi/musik/charger: alpha 1 + bisa disentuh, menggambar kapsul
 *              yang tumbuh dari pill ke bawah dengan spring.
 *
 * Serah-terima P <-> E terjadi dengan bentuk identik (hitam pekat, posisi sama) sehingga mulus.
 * Gravity selalu TOP|CENTER_HORIZONTAL, sehingga kapsul terkunci di tengah atas.
 *
 * Seluruhnya event-driven (tanpa polling): musik & notifikasi dari MediaListenerService,
 * charger dari ACTION_POWER_CONNECTED, posisi/ukuran dari StateFlow IslandPrefs.
 */
class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    override val viewModelStore = ViewModelStore()
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateController.savedStateRegistry

    private lateinit var wm: WindowManager
    private lateinit var pillParams: WindowManager.LayoutParams
    private lateinit var bigParams: WindowManager.LayoutParams
    private var pillRoot: DragLayout? = null
    private var bigRoot: FrameLayout? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var cfg = IslandConfig()
    private var dragStartX = 0
    private var dragStartY = 0

    // Hanya menyala saat kabel/charger dicolokkan (bukan tiap perubahan persen baterai)
    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            MediaRepo.charge.value = ChargeInfo(level)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        startForeground(1, buildNotification())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        IslandPrefs.load(this)
        cfg = IslandPrefs.config.value
        IslandState.reset()
        showWindows()
        updateOrientation()

        // Terapkan perubahan posisi/ukuran dari layar pengaturan secara live
        scope.launch {
            IslandPrefs.config.collect {
                cfg = it
                applyLayout()
            }
        }

        // Penyaji notifikasi: satu coroutine yang tidur sampai ada notifikasi masuk
        MediaRepo.overlayActive = true
        scope.launch { presentNotifications() }
        startOrchestrator()

        ContextCompat.registerReceiver(
            this, powerReceiver, IntentFilter(Intent.ACTION_POWER_CONNECTED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).roundToInt()

    private fun View.bindOwners() {
        setViewTreeLifecycleOwner(this@OverlayService)
        setViewTreeSavedStateRegistryOwner(this@OverlayService)
        setViewTreeViewModelStoreOwner(this@OverlayService)
    }

    private fun newParams(extraFlags: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        BASE_FLAGS or extraFlags,
        PixelFormat.TRANSLUCENT
    ).apply {
        // Terkunci di tengah-atas; offset horizontal hanya mengikuti posisi kamera (0 jika di tengah)
        gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        // Izinkan menggambar sampai area punch-hole / notch
        if (Build.VERSION.SDK_INT >= 30) {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    /** Hanya dipanggil saat pengaturan berubah / drag selesai — TIDAK PERNAH saat animasi. */
    private fun applyLayout() {
        if (!::pillParams.isInitialized) return
        val dm = resources.displayMetrics

        pillParams.width = dp(cfg.pillWidthDp)
        pillParams.height = dp(cfg.pillHeightDp)
        pillParams.x = dp(cfg.xDp)
        pillParams.y = dp(cfg.yDp)

        bigParams.width = min(dp(BIG_W_DP), dm.widthPixels)
        bigParams.height = dp(BIG_H_DP)
        bigParams.x = dp(cfg.xDp)
        bigParams.y = dp(cfg.yDp)

        pillRoot?.let { try { wm.updateViewLayout(it, pillParams) } catch (_: Exception) {} }
        bigRoot?.let { try { wm.updateViewLayout(it, bigParams) } catch (_: Exception) {} }
    }

    private fun showWindows() {
        pillParams = newParams(0)
        bigParams = newParams(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE).apply { alpha = IDLE_ALPHA }
        applyLayout()

        val pillCompose = ComposeView(this).apply {
            bindOwners()
            setContent { PillWindowUI() }
        }
        val pill = DragLayout(this).apply {
            bindOwners()
            addView(
                pillCompose,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            onDragStart = {
                dragStartX = pillParams.x
                dragStartY = pillParams.y
            }
            onDragMove = { dx, dy ->
                pillParams.x = dragStartX + dx.roundToInt()
                pillParams.y = (dragStartY + dy.roundToInt()).coerceAtLeast(0)
                try { wm.updateViewLayout(this, pillParams) } catch (_: Exception) {}
            }
            onDragEnd = {
                val d = resources.displayMetrics.density
                IslandPrefs.set(cfg.copy(xDp = pillParams.x / d, yDp = pillParams.y / d))
                IslandPrefs.save(this@OverlayService)
            }
        }

        val bigCompose = ComposeView(this).apply {
            bindOwners()
            setContent { IslandWindowUI() }
        }
        val big = FrameLayout(this).apply {
            bindOwners()
            addView(
                bigCompose,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        // E ditambahkan setelah P agar berada di atasnya
        wm.addView(pill, pillParams)
        pillRoot = pill
        wm.addView(big, bigParams)
        bigRoot = big
    }

    /** Mengubah flag/alpha saja (frame tidak berubah) -> tidak memicu animasi window dari sistem. */
    private fun setBigInteractive(on: Boolean) {
        bigParams.flags = if (on) {
            bigParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            bigParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        bigParams.alpha = if (on) 1f else IDLE_ALPHA
        bigRoot?.let { try { wm.updateViewLayout(it, bigParams) } catch (_: Exception) {} }
    }

    /** Semua timer berbasis event (satu kali delay), bukan polling. */
    private fun startOrchestrator() {
        // Charger tampil 4 detik
        scope.launch {
            MediaRepo.charge.collectLatest {
                if (it != null) {
                    delay(4000)
                    MediaRepo.charge.value = null
                }
            }
        }
        // Panel musik menutup sendiri 8 detik setelah interaksi terakhir
        scope.launch {
            combine(IslandState.musicOpen, IslandState.tick) { open, _ -> open }.collectLatest { open ->
                if (open) {
                    delay(8000)
                    IslandState.musicOpen.value = false
                }
            }
        }
        // Serah-terima jendela P <-> E
        scope.launch {
            combine(MediaRepo.notif, MediaRepo.charge, IslandState.musicOpen) { n, c, m ->
                n != null || c != null || m
            }.distinctUntilChanged().collectLatest { big ->
                if (big) {
                    setBigInteractive(true)
                    IslandState.bigActive.value = true       // E mulai menggambar pill (identik dengan P)
                    delay(HANDOVER_MS)
                    IslandState.pillHidden.value = true      // lalu P berhenti menggambar
                } else {
                    delay(COLLAPSE_MS)                       // tunggu spring menciut selesai
                    IslandState.pillHidden.value = false     // P menggambar pill lagi
                    delay(HANDOVER_MS)
                    IslandState.bigActive.value = false      // E berhenti menggambar
                    setBigInteractive(false)
                }
            }
        }
    }

    /** Posisi kamera berubah saat landscape; kapsul disembunyikan agar tidak salah tempat. */
    private fun updateOrientation() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val v = if (landscape) View.GONE else View.VISIBLE
        pillRoot?.visibility = v
        bigRoot?.visibility = v
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateOrientation()
        applyLayout()
    }

    private fun buildNotification(): Notification {
        val chId = "island"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(chId, "Dynamic Island", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, chId)
            .setContentTitle("Dynamic Island aktif")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    override fun onDestroy() {
        MediaRepo.overlayActive = false
        scope.cancel()
        MediaRepo.notif.value = null
        IslandState.reset()
        try { unregisterReceiver(powerReceiver) } catch (_: Exception) {}
        pillRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bigRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        pillRoot = null
        bigRoot = null
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
        super.onDestroy()
    }
}
